const studentsData = [
  {
    id: "VOC_001",
    email: "alice@example.com",
    name: "Alice Smith",
    mobile: "9876512345",
    domain: "Web Development",
    college: "Tech University",
    start: "15 May 2024",
    duration: "2 Months",
    photo: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=130&q=80",
    assignments: [true, true, false, true],
    certificate: "#"
  },
  {
    id: "VOC_005",
    email: "arjun.verma@iitd.ac.in",
    name: "Arjun Verma",
    mobile: "9812345678",
    domain: "Data Science",
    college: "IIT Delhi",
    start: "01 June 2024",
    duration: "2 Months",
    photo: "https://randomuser.me/api/portraits/men/45.jpg",
    assignments: [true, true, true, true],
    certificate: "#"
  },
  {
    id: "VOC_006",
    email: "priya.sharma@nitsurat.edu",
    name: "Priya Sharma",
    mobile: "9123456789",
    domain: "UI/UX Design",
    college: "NIT Surat",
    start: "20 May 2024",
    duration: "1 Month",
    photo: "https://randomuser.me/api/portraits/women/65.jpg",
    assignments: [true, true, false],
    certificate: "#"
  },
  {
    id: "VOC_007",
    email: "rahul.mehra@vjit.ac.in",
    name: "Rahul Mehra",
    mobile: "9000012345",
    domain: "Cybersecurity",
    college: "VJTI Mumbai",
    start: "10 July 2024",
    duration: "1.5 Months",
    photo: "https://randomuser.me/api/portraits/men/33.jpg",
    assignments: [true, false, false, true, true],
    certificate: "#"
  },
  {
    id: "VOC_008",
    email: "ananya.singh@vit.ac.in",
    name: "Ananya Singh",
    mobile: "9823456781",
    domain: "Full Stack Development",
    college: "VIT Vellore",
    start: "01 May 2024",
    duration: "3 Months",
    photo: "https://randomuser.me/api/portraits/women/22.jpg",
    assignments: [true, true, true, true, true, true],
    certificate: "#"
  },
  {
    id: "VOC_009",
    email: "rohan.desai@manipal.edu",
    name: "Rohan Desai",
    mobile: "9888899999",
    domain: "AI/ML",
    college: "Manipal University",
    start: "25 June 2024",
    duration: "2 Months",
    photo: "https://randomuser.me/api/portraits/men/52.jpg",
    assignments: [true, false, true],
    certificate: "#"
  },
  {
    id: "VOC_010",
    email: "isha.agarwal@amity.edu",
    name: "Isha Agarwal",
    mobile: "9877771234",
    domain: "Digital Marketing",
    college: "Amity University",
    start: "18 May 2024",
    duration: "1 Month",
    photo: "https://randomuser.me/api/portraits/women/44.jpg",
    assignments: [false, true, true, false],
    certificate: "#"
  }
];


let myChart = null;

function verifyStudent() {
  const id = document.getElementById("identifier").value.trim().toLowerCase();
  const result = document.getElementById("result");

  result.innerHTML = "";
  if (myChart) {
    myChart.destroy();
    myChart = null;
  }

  if (!id) {
    showToast("Please enter an Email or ID", "error");
    return;
  }

  showSpinner(true);
  showToast("Searching...", "info");

  setTimeout(() => {
    showSpinner(false);
    const student = studentsData.find(s =>
      s.email.toLowerCase() === id || s.id.toLowerCase() === id
    );

    if (!student) {
      result.innerHTML = `
        <div class="no-result-message">
          <h3>Student Not Found</h3>
          <p>No student with: <strong>${id}</strong></p>
        </div>`;
      showToast("Student not found", "error");
    } else {
      displayStudent(student);
      showToast("Student found ✅", "success");
    }
  }, 1000);
}

function displayStudent(student) {
  const result = document.getElementById("result");
  const completed = student.assignments.filter(a => a).length;
  const total = student.assignments.length;
  const pending = total - completed;

  result.innerHTML = `
    <div class="card">
      <img src="${student.photo}" alt="${student.name}" />
      <h3>${student.name}</h3>
      <p><strong>Email:</strong> ${student.email}</p>
      <p><strong>Mobile:</strong> ${student.mobile}</p>
      <p><strong>Domain:</strong> ${student.domain}</p>
      <p><strong>College:</strong> ${student.college}</p>
      <p><strong>Start:</strong> ${student.start}</p>
      <p><strong>Duration:</strong> ${student.duration}</p>

      <h4>Assignment Status</h4>
      <div class="assignment-status">
        ${student.assignments.map((a, i) =>
          `<span>${"A" + (i + 1)}: ${a ? "✅ Done" : "❌ Pending"}</span>`
        ).join("")}
      </div>

      <div class="chart-section">
        <h4>Assignment Progress</h4>
        <div class="chart-container">
          <canvas id="assignmentProgressChart"></canvas>
        </div>
      </div>
    </div>
  `;

  renderChart(completed, pending);
}

function renderChart(completed, pending) {
  const ctx = document.getElementById("assignmentProgressChart").getContext("2d");

  myChart = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Completed", "Pending"],
      datasets: [{
        data: [completed, pending],
        backgroundColor: ["#28a745", "#dc3545"]
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: "bottom" }
      }
    }
  });
}

function showToast(msg, type = "info") {
  const toast = document.getElementById("toast");
  toast.innerText = msg;
  toast.className = `toast ${type} show`;

  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.className = "toast", 500);
  }, 3000);
}

function showSpinner(show) {
  const spinner = document.querySelector(".spinner");
  spinner.classList.toggle("hidden", !show);
}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("identifier").addEventListener("keypress", e => {
    if (e.key === "Enter") verifyStudent();
  });
});
